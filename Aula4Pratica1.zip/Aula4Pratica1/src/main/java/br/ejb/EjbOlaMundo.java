/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package br.ejb;

import javax.ejb.Stateless;

/**
 *
 * @author default
 */
@Stateless
public class EjbOlaMundo {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    public String getOi(){
        return "Ola mundo! Todos usam EJB";
    }
}
